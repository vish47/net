﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxation
{
    public class Tax
    {
        public static double PayIT(double amount)
        {
            Console.WriteLine("in PayIT");
            return amount - 100;
        }
    }
}
