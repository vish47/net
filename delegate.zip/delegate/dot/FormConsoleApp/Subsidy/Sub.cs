﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Subsidy
{
    public class Sub
    {
        public static double Subsi(double amount)
        {
            Console.WriteLine(" In subsidy ");
            return amount + 1000;
        }
    }
}
