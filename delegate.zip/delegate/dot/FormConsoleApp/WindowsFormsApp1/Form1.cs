﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;
using DelegateLibrary;
using Taxation;
using Subsidy;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Banking acct;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            acct = new Banking();
            acct.Overbalance += new Operations(Tax.PayIT);
            acct.UnderBalance += Sub.Subsi;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double initialbalance = double.Parse(Balancedata.Text);
            double amount = double.Parse(Amountdata.Text);
            acct.Balance = initialbalance;
            acct.Deposit(amount);
            Updated.Text = acct.Balance.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double initialbalance = double.Parse(Balancedata.Text);
            double amount = double.Parse(Amountdata.Text);
            acct.Balance = initialbalance;
            acct.Withdraw(amount);
            Updated.Text = acct.Balance.ToString();
        }
    }
}
